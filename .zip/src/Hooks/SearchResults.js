


const SearchResults = () => {
  return (

const GetSerachResults= 

    <div>SearchResults</div>
  )
}


