import React from 'react'
import NavBar from './NavBar'

const Login = () => {
  return (
    <div>
        <div>
            <h1 className='text-4xl font-bold text-center'>Login Page</h1>
            <form className='flex flex-col items-center justify-center h-screen'>
            <div className='text-2xl font-semibold'>Email:</div>
                <input type="text" placeholder='Username' className='border w-[400px] border-black rounded-md p-2 m-2'/>
                <div className='text-2xl font-semibold'>Password:</div>
                <input type="password" placeholder='Password' className='border w-[400px] border-black rounded-md p-2 m-2'/>
                <button className='bg-blue-600 text-white rounded-md p-2 m-2'>Login</button>
            </form>
        </div>
    </div>
  )
}

export default Login;