import React from 'react'

const Card = () => {
    return (
        <div>
            <div className="bg-white shadow-md rounded-lg p-4 max-w-sm mx-auto mt-4">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTgaGtN61TSi7QGM9x8IW7mXRooCAUkvZ2lVA&s" alt="Product" className="w-full h-48 object-cover rounded-t-lg" />
                <h2 className="text-xl font-semibold mt-2">T-shirt</h2>
                <p className="text-gray-600 mt-1">$20.00</p>
                <button className="bg-blue-500 text-white px-4 py-2 rounded mt-4 hover:bg-blue-600">Add to Cart</button>
            </div>
        </div>
    )
}

export default Card