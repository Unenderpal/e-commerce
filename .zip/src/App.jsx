import { useState } from 'react'
import './App.css'
import NavBar from './components/NavBar'
import Home from './components/Home'
import Cart from './Cart'
import {  BrowserRouter, Routes, Route } from 'react-router-dom'
import Login from './components/Login'
import SearchResults from './components/SearchResults'

function App() {

  return (
    <div>
   <BrowserRouter> 
   <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/cart" element={<Cart />} />
      <Route path="/login" element={<Login />} />
      <Route path="/search" element={<SearchResults />} />
   </Routes>
   </BrowserRouter>
    </div>
  )

}

export default App
