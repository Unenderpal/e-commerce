import React from 'react'
import { Link } from 'react-router-dom'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom';
const NavBar = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();
  const handelclick = (e) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchTerm)}`)
    }
  }


  return (
    <div className='border border-black flex justify-between items-center bg-white p-4'>
      <div className=' h-20 w-20 rounded-full bg-blue-600'></div>
      <div className='font-semibold flex flex-grow justify-center items-center'>
        <form onSubmit={handelclick}>
          <input
            type="text"
            placeholder="Search products..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button type="submit">Search</button>
        </form>
      </div>
      <div>
        <ul className='flex gap-20 pr-48'>
          <li className='text-2xl font-semibold'><Link to="/" >Home</Link></li>
          <li className='text-2xl font-semibold'><Link to="/shop" >Shop</Link> </li>
          <li className='text-2xl font-semibold'><Link to="/cart">Cart</Link></li>
          <li className='text-2xl font-semibold'><Link to="/login" >Login</Link></li>
        </ul>
      </div>
    </div>
  )
}

export default NavBar;