import React, { useEffect } from 'react'
import { Link, useSearchParams } from 'react-router-dom'

import NavBar from './NavBar'
import Products from './Products'
import Card from './Card'

const SearchResults = () => {


    const [params]=useSearchParams(); 
    const query = params.get("q");   

  console.log(query);

  const GetSearchResult=async()=>{ 
    const Respo= await fetch('https://dummyjson.com/products')
const data = await Respo.json()

console.log(data?.products);
  }
  useEffect(()=>{
    GetSearchResult()
  },[query])
 
  return (
    <div>
        <NavBar/>
        <Card />
    </div>
  )
}

export default SearchResults