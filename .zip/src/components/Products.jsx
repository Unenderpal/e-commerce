import React from 'react'
import Card from './Card'

const Products = () => {
  return (
    <div className="flex flex-wrap p-10 items-start gap-10 justify-center h-auto bg-gray-100">
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
    </div>
  )
}

export default Products